// import React from "react";

const loginList = [
  {
    email: "mary@gmail.com",
    pass: "123"
  },
  {
    email: "john@yahoo.com",
    pass: "456"
  },
  {
    email: "clint@hotmail.com",
    pass: "789"
  }
];

export default loginList;

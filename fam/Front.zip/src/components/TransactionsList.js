function transactionList() {
  const transactionList = [
        {
          companyName: "Company4",
          currencyFrom: 'AU',
          value: 1500,
          fee: 10,
          totalFee: 100,
          currencyTo: 'BRL',
          valueConv: 4000,
          youGot: 1000,
          youGotConv: 1000,
          time: '30 days',

        },
        {
          companyName: "Company4",
          currencyFrom: 'AU',
          value: 'AU',
          fee: 111,
          totalFee: 100,
          currencyTo: 'AU',
          valueConv: 'AU',
          youGot: 1000,
          youGotConv: 1000,
          time: '30 days',

        },
        {
          companyName: "Company4",
          currencyFrom: 'AU',
          value: 'AU',
          fee: 111,
          totalFee: 100,
          currencyTo: 'AU',
          valueConv: 'AU',
          youGot: 1000,
          youGotConv: 1000,
          time: '30 days',

        },
      ]
    
  return transactionList;
}

export default transactionList;
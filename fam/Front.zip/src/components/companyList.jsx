function companyList() {
    const companyList = [
      {
        companyName: "Company1",
        fee: 0.05,
        time: "10 days"
      },
      {
        companyName: "Company2",
        fee: 0.06,
        time: "2 days"
      },
      {
        companyName: "Company3",
        fee: 0.03,
        time: "15 days"
      },
      {
        companyName: "Company4",
        fee: 0.01,
        time: "30 days"
      },
      
    ];
    return companyList;
  }
  
  export default companyList;
  
